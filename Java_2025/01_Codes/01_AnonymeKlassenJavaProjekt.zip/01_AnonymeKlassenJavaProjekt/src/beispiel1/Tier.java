package beispiel1;

// Superklasse mit Standardverhalten
public class Tier {
    public void macheGeräusch() {
        System.out.println("Ein Tier macht ein Geräusch."); // Ausgabe: Ein Tier macht ein Geräusch.
    }
}

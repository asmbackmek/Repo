package beispiel3;

public class Katze {
    public void gibLaut() {
        System.out.println("Miau!"); // Ausgabe: Miau!
    }
}

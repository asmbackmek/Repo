package beispiel5;

public interface Fahrbar {
    void fahren();
}

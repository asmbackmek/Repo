package beispiel2;

public interface Laufbar {
    void laufen();
}

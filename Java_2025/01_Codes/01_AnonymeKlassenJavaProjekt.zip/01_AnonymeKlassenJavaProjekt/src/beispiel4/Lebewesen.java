package beispiel4;

public abstract class Lebewesen {
    public abstract void fressen();
}

// Interface Fahrzeug definiert gemeinsame Methoden für alle Fahrzeugtypen
public interface Fahrzeug {
    String getMarke();
    String getModell();
    double getTagespreis();
}
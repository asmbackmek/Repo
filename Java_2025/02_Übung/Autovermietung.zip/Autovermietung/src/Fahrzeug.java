public interface Fahrzeug {
    String getMarke();
    String getModell();
    double getTagespreis();
}
